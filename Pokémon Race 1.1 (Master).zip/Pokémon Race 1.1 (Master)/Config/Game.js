class Game {
    constructor() {

    }
    getState() {
        database.ref("gameState").on("value", (data)=> {
            gameState = data.val();
        })
    }
    update(state) {
        database.ref("/").update({
            gameState: state
        });
    }
    async start() {
        if (gameState === 0) {
            player = new Player();
            var playerCountRef = await database.ref("playerCount");
            playerCountRef.on("value", (data)=> {
                playerCount = data.val();
            });
            login = new Login();
            login.display();
        }
        pokemon1 = createSprite(50, 10, 50, 50);
        pokemon1.scale = 0.8;
        pokemon2 = createSprite(50, 10, 50, 50);
        pokemon2.scale = 0.8;
        pokemon3 = createSprite(50, 10, 50, 50);
        pokemon3.scale = 0.8;
        pokemon4 = createSprite(50, 10, 50, 50);
        pokemon4.scale = 0.8;
        pokemon5 = createSprite(50, 10, 50, 50);
        pokemon5.scale = 0.8;
        pokemons = [pokemon1, pokemon2, pokemon3, pokemon4, pokemon5];
    }
    play() {
        login.hide();
        document.body.setAttribute("style", "background-color: #0000FF");
        image(bgImg, trackPos, camera.position.y - (displayHeight / 1.9), displayWidth * 5.3, displayHeight * 1.2);
        Player.getPlayerInfo();
        if (allPlayers !== undefined) {
            var y = 100;
            var index = 0;
            for (var plr in allPlayers) {
                var x = allPlayers[plr].distance;
                index += 1;
                if (x === 0 && index === player.index) {
                    trackPos = camera.position.x;
                }
                if (addImages === true) {
                this.fetchImages();
                switch (index) {
                    case 1:
                        pokemons[index - 1].addImage(p1Img);
                    break;
                    case 2:
                        pokemons[index - 1].addImage(p2Img);
                    break;
                    case 3:
                        pokemons[index - 1].addImage(p3Img);
                    break;
                    case 4:
                        pokemons[index - 1].addImage(p4Img);
                    break;
                    case 5:
                        pokemons[index - 1].addImage(p5Img);
                        addImages = false;
                    break;
                }
            }
                y = y + 300;
                pokemons[index - 1].x = x;
                pokemons[index - 1].y = y;
                if (player.index === index) {
                    camera.position.x = pokemons[index - 1].x;
                    camera.position.y = pokemons[index - 1].y;
                    pokemons[index - 1].shapeColor ="#00FF00";
                    fill("#00FF00");
                    noStroke();
                    circle(pokemons[index - 1].x - 200, pokemons[index - 1].y, 40);
                    textSize(30);
                    textAlign(CENTER);
                    textFont(font);
                    text(player.name, pokemons[index - 1].x, pokemons[index - 1].y - 130);

                }
                else {
                    fill("#FF0000");
                    noStroke();
                    circle(pokemons[index - 1].x - 200, pokemons[index - 1].y, 40);
                    textSize(30);
                    textAlign(CENTER);
                    textFont(font);
                    text(allPlayers[plr].name, pokemons[index - 1].x, pokemons[index - 1].y - 130);
                }
            }
        }
        if (keyDown("space") && player.index !== null && player.rank === null) {
            player.distance += 20;
            player.update();
        }
        database.ref("PokemonsAtEnd").on("value", (data)=> {
            pokemonsAtEnd = data.val();
        });
        if (player.distance > 6980) {
            if (player.rank === null) {
            pokemonsAtEnd += 1;
            player.rank = pokemonsAtEnd;
            player.update();
            database.ref("/").update({
            PokemonsAtEnd: pokemonsAtEnd
            });
            }
            fill("blue");
            textSize(50);
            textFont(font);
            stroke("yellow");
            strokeWeight(1);
            text("Finished", camera.position.x + 150, camera.position.y - 200);
        }
        if (pokemonsAtEnd === 5) {
            game.update(2);
            gameState = 2;
        }
        drawSprites();
    }
    fetchImages() {
        Player.getPlayerInfo();
        if (allPlayers !== undefined) {
            var index = 0;
            for (var plr in allPlayers) {
                index += 1;
                switch (index) {
                    case 1:
                        p1Img = loadImage(allPlayers[plr].pokemon);
                    break;
                    case 2:
                        p2Img = loadImage(allPlayers[plr].pokemon);
                    break;
                    case 3:
                        p3Img = loadImage(allPlayers[plr].pokemon);
                    break;
                    case 4:
                        p4Img = loadImage(allPlayers[plr].pokemon);
                    break;
                    case 5:
                        p5Img = loadImage(allPlayers[plr].pokemon);
                    break;
                }
    }
}
}
    end() {
        login.hide();
        fill("#00FF00");
        rect(camera.position.x - canvas.width / 2.3, camera.position.y - canvas.height / 2.4, canvas.width - 200, canvas.height - 150);
        Player.getPlayerInfo();
        textSize(40);
        fill(0);
        textAlign(CENTER);
        textFont(font);
        text("Leaderboard", camera.position.x, camera.position.y - canvas.height / 3);
        if (allPlayers !== undefined) {
            for (var plr in allPlayers) {
                textSize(30);
                var minusQuantity = canvas.height / 6;
                minusQuantity -= minusQuantity / 5;
                switch (allPlayers[plr].rank) {
                    case 1:
                        fill("yellow");
                        text(allPlayers[plr].rank + "st Place is " + allPlayers[plr].name, (camera.position.x + canvas.width / 6) - canvas.width / 2, camera.position.y - (minusQuantity * 2));
                    break;
                    case 2:
                        fill("gray");
                        text(allPlayers[plr].rank + "nd Place is " + allPlayers[plr].name, (camera.position.x + canvas.width / 6) - canvas.width / 2, camera.position.y - minusQuantity);
                    break;
                    case 3:
                        fill("#BA9800");
                        text(allPlayers[plr].rank + "rd Place is " + allPlayers[plr].name, (camera.position.x + canvas.width / 6) - canvas.width / 2, camera.position.y);
                    break;
                    case 4:
                        fill("blue");
                        text(allPlayers[plr].rank + "th Place is " + allPlayers[plr].name, (camera.position.x + canvas.width / 6) - canvas.width / 2, camera.position.y + minusQuantity);
                    break;
                    case 5:
                        fill("blue");
                        text(allPlayers[plr].rank + "th Place is " + allPlayers[plr].name, (camera.position.x + canvas.width / 6) - canvas.width / 2, camera.position.y + (minusQuantity * 2));
                    break;
                    default:
                        fill("black");
                        text(allPlayers[plr].rank + "st Place is " + allPlayers[plr].name, (camera.position.x + canvas.width / 6) - canvas.width / 2, canvas.height * (6/7) + 20);
                    break;
                }
            }
        }
    }
}